<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('usuario', function (Blueprint $table) {
            $table->id('id_usuario');
        $table->string('nombre', 100);
        $table->string('email', 100)->unique();
        $table->string('password', 255);
        $table->enum('genero', ['M', 'F', 'O']);
        $table->text('direccion')->nullable();
        $table->string('nacionalidad', 100)->nullable();
        $table->string('num_telefono', 15)->nullable();
        $table->date('fecha_nacimiento')->nullable();
        $table->string('perfil', 255);
        $table->enum('estado', ['activo', 'inactivo', 'suspendido']);
        $table->foreignId('rol_id')->nullable()->constrained('roles');
        $table->timestamp('fecha_registro')->useCurrent();
        $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('usuario');
    }
};
